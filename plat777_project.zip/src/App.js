
import React, { useState, useEffect } from 'react';
import firebaseConfig from './firebaseConfig';
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  getDocs,
} from 'firebase/firestore';

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const SYMBOLS = [
  { symbol: '🔮', name: 'Raro', payout: 10, chance: 0.02 },
  { symbol: '💎', name: 'Médio', payout: 5, chance: 0.05 },
  { symbol: '🍒', name: 'Comum', payout: 3, chance: 0.10 },
  { symbol: '🍋', name: 'Outro', payout: 0, chance: 0.83 },
];

function getRandomSymbol() {
  const rand = Math.random();
  let sum = 0;
  for (const s of SYMBOLS) {
    sum += s.chance;
    if (rand <= sum) return s;
  }
  return SYMBOLS[SYMBOLS.length - 1];
}

function App() {
  const [user, setUser] = useState(null);
  const [balance, setBalance] = useState(0);
  const [reels, setReels] = useState(['?', '?', '?']);
  const [message, setMessage] = useState('');
  const [bet, setBet] = useState(1);
  const [admin, setAdmin] = useState(false);

  useEffect(() => {
    onAuthStateChanged(auth, async (u) => {
      if (u) {
        setUser(u);
        // Buscar saldo
        const userDoc = doc(db, 'users', u.uid);
        const userSnap = await getDoc(userDoc);
        if (userSnap.exists()) {
          setBalance(userSnap.data().balance || 0);
          setAdmin(userSnap.data().admin || false);
        } else {
          await setDoc(userDoc, { balance: 0, admin: false });
          setBalance(0);
          setAdmin(false);
        }
      } else {
        setUser(null);
        setBalance(0);
        setAdmin(false);
      }
    });
  }, []);

  const login = () => {
    const provider = new GoogleAuthProvider();
    signInWithPopup(auth, provider);
  };

  const logout = () => {
    signOut(auth);
  };

  const play = async () => {
    if (bet > balance) {
      setMessage('Saldo insuficiente para apostar');
      return;
    }
    // Tirar o valor da aposta
    setBalance((b) => b - bet);
    await updateDoc(doc(db, 'users', user.uid), { balance: balance - bet });

    // Girar os 3 rolos
    const r1 = getRandomSymbol();
    const r2 = getRandomSymbol();
    const r3 = getRandomSymbol();
    setReels([r1.symbol, r2.symbol, r3.symbol]);

    // Verificar vitória (3 iguais)
    if (r1.symbol === r2.symbol && r2.symbol === r3.symbol && r1.payout > 0) {
      const ganho = bet * r1.payout;
      setMessage(`Parabéns! Você ganhou ${ganho} moedas!`);
      const newBalance = balance - bet + ganho;
      setBalance(newBalance);
      await updateDoc(doc(db, 'users', user.uid), { balance: newBalance });
    } else {
      setMessage('Tente novamente!');
    }
  };

  return (
    <div style={{ maxWidth: 400, margin: 'auto', padding: 20, fontFamily: 'Arial' }}>
      <h1>Plat777 - Caça Níquel</h1>
      {user ? (
        <>
          <p>Olá, {user.displayName}</p>
          <p>Saldo: {balance} moedas</p>
          <div style={{ fontSize: 40, marginBottom: 10 }}>
            {reels[0]} {reels[1]} {reels[2]}
          </div>
          <input
            type="number"
            min="1"
            max={balance}
            value={bet}
            onChange={(e) => setBet(Number(e.target.value))}
            style={{ width: '100%' }}
          />
          <button onClick={play} disabled={balance < bet}>
            Apostar
          </button>
          <button onClick={logout} style={{ marginTop: 10 }}>
            Sair
          </button>
          <p>{message}</p>
          {admin && <p style={{ color: 'red' }}>Você é admin</p>}
        </>
      ) : (
        <button onClick={login}>Entrar com Google</button>
      )}
    </div>
  );
}

export default App;
