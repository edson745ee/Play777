
# Plataforma Plat777 - Projeto Completo

## Descrição
Projeto React + Firebase com:
- Jogo de caça-níquel (slots) com símbolos raros e probabilidades.
- Sistema de saldo real.
- Autenticação Google.
- Depósito e saque com controle de admin.
- Regras para saques baseadas em depósito e gasto.

## Como rodar localmente

1. Instale Node.js
2. Rode `npm install`
3. Configure seu Firebase em `src/firebaseConfig.js`
4. Rode `npm start`

## Como publicar

1. Rode `npm run build`
2. Instale Firebase CLI e faça `firebase init hosting` com pasta `build`
3. Rode `firebase deploy`

## Observações

- Substitua as chaves Firebase no arquivo `src/firebaseConfig.js`
- Admin deve ser configurado no Firestore manualmente

---

Qualquer dúvida, me pergunte!
