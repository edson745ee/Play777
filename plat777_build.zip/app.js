
// Código JS simples para simular o jogo de aposta React-like (sem React para simplicidade no build)

const root = document.getElementById('root');

let balance = 100;
let betAmount = 10;

const symbols = [
  { name: 'Raro', emoji: '💎', chance: 0.02, payout: 10 },
  { name: 'Médio', emoji: '⭐', chance: 0.05, payout: 5 },
  { name: 'Comum', emoji: '🍒', chance: 0.10, payout: 3 },
  { name: 'Outros', emoji: '🍀', chance: 0.83, payout: 0 }
];

function getRandomSymbol() {
  const rand = Math.random();
  let acc = 0;
  for (let sym of symbols) {
    acc += sym.chance;
    if (rand <= acc) return sym;
  }
  return symbols[symbols.length - 1];
}

function play() {
  if (balance < betAmount) {
    alert('Saldo insuficiente para apostar.');
    return;
  }
  balance -= betAmount;

  const results = [];
  for (let i = 0; i < 3; i++) {
    results.push(getRandomSymbol());
  }

  // Verifica combinações
  const counts = {};
  results.forEach(s => counts[s.name] = (counts[s.name] || 0) + 1);

  let winAmount = 0;
  let winMessage = 'Você perdeu! Tente de novo.';

  // Se 3 símbolos iguais, paga baseado no payout
  for (let sym of symbols) {
    if ((counts[sym.name] || 0) === 3) {
      winAmount = betAmount * sym.payout;
      break;
    }
  }

  if (winAmount > 0) {
    balance += winAmount;
    winMessage = `Parabéns! Você ganhou ${winAmount} moedas!`;
  }

  render(results, winMessage);
}

function render(results = [], message = '') {
  root.innerHTML = `
    <div class="balance">Saldo: ${balance.toFixed(2)} moedas</div>
    <button onclick="play()">Jogar (Aposta ${betAmount} moedas)</button>
    <div class="symbols">
      ${results.map(s => `<div class="symbol">${s.emoji}</div>`).join('')}
    </div>
    <div class="result">${message}</div>
  `;
}

// Inicializa
render();
    